"""Run with the installed ReplayLab runtime; pass parameters/confirmation via CLI flags."""
from pathlib import Path
import subprocess
import sys

workflow = Path(__file__).resolve().parents[1] / "workflow.json"
raise SystemExit(subprocess.call(["replaylab", "run-workflow", str(workflow), *sys.argv[1:]]))
