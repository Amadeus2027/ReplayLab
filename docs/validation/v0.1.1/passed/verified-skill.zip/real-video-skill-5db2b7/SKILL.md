---
name: real-video-skill-5db2b7
description: Replay a reviewed browser workflow recovered from a demonstration video using the ReplayLab CLI.
---

# ReplayLab verified workflow

1. Read `workflow.json`, including preconditions, allowed origins, parameters and sensitive steps.
2. Explain the concrete actions to the user and obtain authorization for the task.
3. Install ReplayLab 0.1.1 and its Playwright browser if absent. The runtime is an external dependency.
4. Run `python scripts/run.py --params-file /path/to/parameters.json` from this skill directory.
   Omit `--params-file` when no parameters are required. Parameter files are JSON string maps.
5. Add `--confirm-sensitive` only when the user explicitly authorizes the sensitive actions.
6. Inspect the report path printed by the CLI. On failure or pause, stop and report the reason.
   Do not silently retry submissions or claim completion from partial success.

`verification.json` records a previous run, not a guarantee of future success.
The runtime opens a fresh isolated browser and does not import user cookies.
